#ifndef __LV_LABEL_TEST_H__
#define __LV_LABEL_TEST_H__
#include "sys.h"








//��������
void lv_label_test_start(void);
void key_handler(void);

#endif


