#ifndef __LV_OBJ_TEST_H__
#define __LV_OBJ_TEST_H__
#include "sys.h"








//��������
void lv_obj_test_start(void);
void key_handler(void);

#endif


